import 'package:flutter/material.dart';
import 'word_data.dart';
import 'word_card.dart';

void main() {
  runApp(TilSozApp());
}

class TilSozApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'TilSöz',
      theme: ThemeData(primarySwatch: Colors.teal),
      home: CategoryScreen(),
    );
  }
}

class CategoryScreen extends StatelessWidget {
  final List<String> categories = ['Animals'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('TilSöz - Categories')),
      body: ListView.builder(
        itemCount: categories.length,
        itemBuilder: (context, index) {
          return ListTile(
            title: Text(categories[index]),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(builder: (context) => WordListScreen()),
              );
            },
          );
        },
      ),
    );
  }
}

class WordListScreen extends StatelessWidget {
  final words = animalWords;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Animals')),
      body: ListView.builder(
        itemCount: words.length,
        itemBuilder: (context, index) {
          return WordCard(word: words[index]);
        },
      ),
    );
  }
}
