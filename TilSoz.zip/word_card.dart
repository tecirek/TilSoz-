import 'package:flutter/material.dart';
import 'word_data.dart';

class WordCard extends StatelessWidget {
  final Word word;

  WordCard({required this.word});

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(10),
      child: ListTile(
        title: Text('${word.kazakh} - ${word.english}', style: TextStyle(fontSize: 18)),
        subtitle: Text('Latin: ${word.latin}'),
      ),
    );
  }
}
