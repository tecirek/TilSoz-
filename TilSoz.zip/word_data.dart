class Word {
  final String kazakh;
  final String english;
  final String latin;

  Word({required this.kazakh, required this.english, required this.latin});
}

final List<Word> animalWords = [
  Word(kazakh: 'ит', english: 'dog', latin: 'it'),
  Word(kazakh: 'мысық', english: 'cat', latin: 'mysıq'),
  Word(kazakh: 'жылқы', english: 'horse', latin: 'jylqy'),
  Word(kazakh: 'құс', english: 'bird', latin: 'qus'),
  Word(kazakh: 'сиыр', english: 'cow', latin: 'siyr'),
  Word(kazakh: 'қой', english: 'sheep', latin: 'qoy'),
  Word(kazakh: 'түйе', english: 'camel', latin: 'tüýe'),
  Word(kazakh: 'аю', english: 'bear', latin: 'ayu'),
  Word(kazakh: 'балық', english: 'fish', latin: 'balyq'),
  Word(kazakh: 'арыстан', english: 'lion', latin: 'arystan'),
];
